document.addEventListener('DOMContentLoaded', function () {

  // PILLS
  document.querySelectorAll('.pill').forEach(function (pill) {
    pill.addEventListener('click', function () {
      document.querySelectorAll('.pill').forEach(function (p) { p.classList.remove('active'); });
      document.querySelectorAll('.panel').forEach(function (p) { p.classList.remove('active'); });
      pill.classList.add('active');
      document.getElementById(pill.getAttribute('data-panel')).classList.add('active');
    });
  });

  // GENERATE + AUTO COPY
  document.getElementById('genBtn').addEventListener('click', function () {
    var firstSeven = Math.floor(1000000 + Math.random() * 9000000).toString();
    var awb = firstSeven + (parseInt(firstSeven) % 7);
    var el = document.getElementById('genResult');
    var btn = document.getElementById('genBtn');
    el.innerText = awb;
    el.style.color = '#00d4ff';
    el.style.fontSize = '22px';
    el.style.letterSpacing = '3px';
    navigator.clipboard.writeText(awb).then(function () {
      btn.innerText = 'Copied!';
      btn.style.background = '#22c55e';
      setTimeout(function () {
        btn.innerText = 'Generate Random';
        btn.style.background = '';
      }, 1500);
    });
  });

  // VERIFY
  document.getElementById('checkBtn').addEventListener('click', function () {
    var input = document.getElementById('awbInput').value.trim();
    var res = document.getElementById('checkResult');
    if (input.length !== 8 || isNaN(input)) {
      res.innerText = 'Need 8 digits';
      res.className = 'result invalid';
      return;
    }
    var expected = parseInt(input.substring(0, 7)) % 7;
    var actual   = parseInt(input.substring(7, 8));
    if (actual === expected) {
      res.innerText = 'Valid';
      res.className = 'result valid';
    } else {
      res.innerText = 'Invalid (exp. ' + expected + ')';
      res.className = 'result invalid';
    }
  });

  document.getElementById('awbInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') document.getElementById('checkBtn').click();
  });

  // SEQUENCE
  document.getElementById('seqGenBtn').addEventListener('click', function () {
    var prefix   = document.getElementById('seqPrefix').value.trim();
    var startRaw = document.getElementById('seqStart').value.trim();
    var count    = Math.min(parseInt(document.getElementById('seqCount').value) || 10, 20);

    if (prefix.length !== 3 || isNaN(prefix)) { alert('Enter a valid 3-digit airline prefix'); return; }
    if (startRaw.length !== 7 || isNaN(startRaw)) { alert('Enter a valid 7-digit starting serial'); return; }

    var start = parseInt(startRaw);
    var awbs  = [];
    var list  = document.getElementById('seqList');
    list.innerHTML = '';

    for (var i = 0; i < count; i++) {
      var serial = start + i;
      if (serial > 9999999) break;
      var awb = prefix + '-' + String(serial).padStart(7, '0') + (serial % 7);
      awbs.push(awb);
      (function (val) {
        var item = document.createElement('div');
        item.className = 'seq-item';
        var spanVal = document.createElement('span');
        spanVal.textContent = val;
        var spanCopy = document.createElement('span');
        spanCopy.className = 'seq-item-copy';
        spanCopy.textContent = 'copy';
        item.appendChild(spanVal);
        item.appendChild(spanCopy);
        item.addEventListener('click', function () {
          navigator.clipboard.writeText(val).then(function () {
            item.querySelector('.seq-item-copy').innerText = 'copied!';
            setTimeout(function () { item.querySelector('.seq-item-copy').innerText = 'copy'; }, 1500);
          });
        });
        list.appendChild(item);
      })(awb);
    }

    document.getElementById('seqOutputLabel').innerText = awbs.length + ' AWBs generated';
    document.getElementById('seqOutput').style.display = 'flex';

    document.getElementById('seqCopyAll').onclick = function () {
      navigator.clipboard.writeText(awbs.join('\n')).then(function () {
        document.getElementById('seqCopyAll').innerText = 'Copied!';
        setTimeout(function () { document.getElementById('seqCopyAll').innerText = 'Copy All'; }, 2000);
      });
    };
  });

});